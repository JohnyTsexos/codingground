import java.util.Scanner;
import java.io.BufferedReader;
import java.io.InputStreamReader;
public class HelloWorld{

     public static void main(String []args){
            int[] rooms={0,1,2,3,4,5,6,7,8,9};
           int[] roomDoors= {0, 2, 3, 2, 3, 4 ,3 ,2 ,3 ,2};
          int myRoom=0;
          int i=0;
          int y=0;
          int nextRoom=0;
          boolean state= true;
          /*
          System.out.println("      |-| ");
          System.out.println("     _____ ");
          System.out.println("   /    \\  \\           _ ");
          System.out.println("   | _  |  |        |_|  ");
          System.out.println(" __|| | | _|___**____|_____**__");
          System.out.println("it is dark...must be midnight....");
          System.out.println("You wake up...an old house next to you....");
          System.out.println("A label...scratched and empty...");
          System.out.println("You enter the main door... a number hanging on the door bell....");
          System.out.println("..9..");
            */
        //******initialization************************************
        //CHECK ROOM CHOICE
        //System.out.println("inside the room there are " + roomDoors[myRoom-1] + " doors....");
         
         
         //main LOOP
         while(state){
         
         
          Scanner sc = new Scanner(System.in);
          int number;
          number = sc.nextInt();
          for(i=0;i<10;i++){
         if(number ==rooms[i]){
               System.out.println("You entered room no: " + number +" which has: "+roomDoors[number] +" rooms");
            }else if(number < 0 || number > 10){
             break;
                }
          }
         
          }  
        //FINISH COISE ROOM
        
     }
     
     
}
